package com.hcc.advweb;

import java.util.ArrayList;

public class StudentsList {

	private static ArrayList<Student> studentsList;
	
	public static ArrayList<Student> getStudentsList() {
		if ((studentsList == null) || (studentsList.size() == 0)) {
			studentsList = new ArrayList<Student>();
			studentsList.add(new Student(1,"Steve","Murray"));
			studentsList.add(new Student(2,"Stephanie","Hill"));
			studentsList.add(new Student(3,"Samuel","Garcia"));
			studentsList.add(new Student(4,"Sarah","Evans"));
			studentsList.add(new Student(5,"John","Chapman"));
		}
		System.out.println("Student List ---->"+studentsList);
		return studentsList;
	}
	public static void setStudentsList(ArrayList<Student> studentsList) {
		studentsList = studentsList;
	}

	public static ArrayList<Student> addStudent(Student student) {
		getStudentsList().add(student);
		return studentsList;
	}
	
	public static ArrayList<Student> removeStudent(Student student) {
		getStudentsList().remove(student);
		return studentsList;
	}
	

}
